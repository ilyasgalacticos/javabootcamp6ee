package servlets;

import db.DBManager;
import db.Item;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.ArrayList;

@WebServlet(value = "/details")
public class DetailsServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String id = req.getParameter("idshka");
        try{
            int idInt = Integer.parseInt(id);
            Item item = DBManager.getItem(idInt);
            req.setAttribute("tovar", item);
        }catch (Exception e){
        }
        req.getRequestDispatcher("/details.jsp").forward(req, resp);
    }
}
